export interface StringUntrusted {
    readonly escaped: string;
    readonly raw: string;
}
