export declare const SCROLLING_SPEED: number;
