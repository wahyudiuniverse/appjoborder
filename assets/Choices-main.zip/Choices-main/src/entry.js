import Choices from './scripts/choices';

export default Choices;
